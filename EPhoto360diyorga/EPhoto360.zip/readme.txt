mana buni
https://saytingiz/writeText?output=image&effect=https://en.ephoto360.com/paint-splatter-text-effect-338.html&text=$text
bunday ishlatmaysiz!??
bunday ishlatishingiz kerak??
buni qo'yasiz
https://saytingiz/?act=writeText&output=image&effect=https://en.ephoto360.com/paint-splatter-text-effect-338.html&text=$text
xato qilsangiz ishlamasligi mumkin!
@PRAKUROR1 va @DAMAS_BASS 
Kod Xvest.Ru da 100% Ishlaydi!

@Sirojiddin6326 Kanali orqali tarqatildi!

